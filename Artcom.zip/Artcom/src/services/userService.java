/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entités.user;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.dbconnexion;

/**
 *
 * @author Sawssen
 */
public class userService {
    private static userService instance;
    private Statement st;
    private ResultSet rs;
    private userService() {
        dbconnexion db = dbconnexion.getInstance();
        try {
            st=db.getCnx().createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(userService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static userService getInstance(){
        if(instance==null) 
            instance=new userService();
        return instance;
    }
    public List<user> getAllUsers() {
        String req="select * from user";
        List<user> list=new ArrayList<>();
        
        try {
            rs=st.executeQuery(req);
            while(rs.next()){
                user u=new user();
                u.setId_user(rs.getInt(1));
                u.setNom(rs.getString("nom"));
                list.add(u);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(userService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
}
