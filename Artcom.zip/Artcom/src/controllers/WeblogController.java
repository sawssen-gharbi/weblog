/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entités.user;
import entités.weblog;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import services.userService;
import services.weblogService;

/**
 * FXML Controller class
 *
 * @author Sawssen
 */
public class WeblogController implements Initializable {
    
    @FXML
    private Button testbtn;
    @FXML
    private Button testdel;
    @FXML
    private Button testup;
    @FXML
    private Label testlabel;
    private user currentUser;
    private TextField testtx;
    private Button testadd;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void initData(user u) {
        this.currentUser = u;
        testlabel.setText("Bienvenue" + currentUser.getNom());
    }
    
    @FXML
    private void handle_test(ActionEvent event) {
        weblogService sl = weblogService.getInstance();
        weblog s = new weblog(1, "phptography", "ff", "ff", "ff");
        
        if (event.getSource() == testbtn) {
            sl.insertWeblog(s);
            
        }
    }
    
    @FXML
    private void handle_delete(ActionEvent event) {
        weblogService sl = weblogService.getInstance();
        
        weblog s1 = new weblog(1, 4, "photography", "ff", "ff", "ff");
        
        if (event.getSource() == testdel) {
            sl.deleteWeblog(s1);
            
        }
    }

    @FXML
    private void handle_up(ActionEvent event) {

        weblogService sl = weblogService.getInstance();

        weblog s2 = new weblog(5, 1, "inforgraphic", "ff", "ff", "ff");

        if (event.getSource() == testup) {
            sl.updateWeblog(s2);
        }

    }
   

    

            

    }
    

